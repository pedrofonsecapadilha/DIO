﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsTreinamento
{
    public class btnRibbon : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            trace.Trace("Minha Primeira Action executada com sucesso!");

            // Verificar se a ação é chamada de uma entidade específica (no exemplo, "cursos_alunos")
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
            {
                EntityReference entidadeRef = (EntityReference)context.InputParameters["Target"];

                if (context.MessageName.ToLower() == "create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entidadeContexto = (Entity)context.InputParameters["Target"];

                    if (entidadeContexto.LogicalName == "cursos_alunos")
                    {
                        if (entidadeContexto.Attributes.Contains("cursos_observacoes"))
                        {
                            string observacoes = entidadeContexto.GetAttributeValue<string>("cursos_observacoes");

                            entidadeContexto["cursos_observacoes"] = " - Botão Action Acionado - Limpou texto anterior da observações";
                        }
                        else
                        {
                            entidadeContexto.Attributes["cursos_observacoes"] = " - Botão Action Acionado - Limpou texto anterior da observações";
                        }

                        serviceAdmin.Update(entidadeContexto);
                    }
                }
            }
        }
    }
}