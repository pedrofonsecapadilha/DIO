﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;

namespace PluginsTreinamento
{
    public class PluginAssincPostOperation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

                IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

                ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                if (context.MessageName.ToLower() == "create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entidadeContexto = (Entity)context.InputParameters["Target"];

                    if (entidadeContexto.LogicalName == "cursos_alunos")
                    {
                        if (entidadeContexto.Attributes.Contains("cursos_observacoes"))
                        {
                            string observacoes = entidadeContexto.GetAttributeValue<string>("cursos_observacoes");

                            observacoes += " - Texto inserido via Plugin Post Operation ASSÍNCRONO";

                            entidadeContexto["cursos_observacoes"] = observacoes;
                        }
                        else
                        {
                            entidadeContexto.Attributes["cursos_observacoes"] = " - Texto inserido via Plugin Post Operation ASSÍNCRONO";
                        }

                        serviceAdmin.Update(entidadeContexto);
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException("Erro ocorrido: " + ex.Message);
            }
        }
    }
}